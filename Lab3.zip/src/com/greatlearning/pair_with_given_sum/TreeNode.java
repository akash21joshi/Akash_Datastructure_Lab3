package com.greatlearning.pair_with_given_sum;

// TreeNode class 
public class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;

	TreeNode() {
	};

	TreeNode(int val) {
		this.val = val;
	}
}